const express = require("express");
const https = require("https");

const router = express.Router();

//Error handling
const sendError = (err, res) => {
    response.status = 501;
    response.message = typeof (err) == "object" ? err.message : err;
    res.status(501).json(response);
};

//Read Products
router.get("/products", (req, res) => {
    https
        .get("https://68pj8rv2y0.execute-api.eu-west-1.amazonaws.com/dev/products", response => {
            var responseData = [];

            response.setEncoding('utf8');
            response.on('data', d => {
                var data = JSON.parse(d);
                var total = data.total;
                var i = 0;
                //Reading product by ID
                data["data"].forEach(element => {
                    https
                        .get("https://68pj8rv2y0.execute-api.eu-west-1.amazonaws.com/dev/products/" + element.id, resp => {
                            resp.setEncoding('utf8');
                            resp.on('data', d => {
                                var elem = JSON.parse(d);
                                var asset = elem.data.elements.filter(item => { return item.name == "main_image" && item.value.subtype == "image" });
                                var assetID = asset && asset[0].value.id;

                                //Reading image from assets
                                if (assetID) {
                                    https
                                        .get("https://68pj8rv2y0.execute-api.eu-west-1.amazonaws.com/dev/assets/" + assetID, response => {
                                            i++;                                            
                                            response.setEncoding('utf8');
                                            response.on('data', d => {
                                                var asset = JSON.parse(d);

                                                elem.imageURL = asset.data.uri;
                                                responseData.push(elem);

                                                if (i == total) {
                                                    res.json(responseData);
                                                }
                                            });
                                        })
                                        .on('error', (e) => {
                                            console.error(e);
                                        });
                                } else {
                                    i++;
                                    elem.data.imageURL = null;
                                    responseData.push(elem);

                                    if (i == total) {
                                        res.json(responseData);
                                    }
                                }
                            });
                        })
                        .on('error', (e) => {
                            i++;
                            console.error(e);
                        });
                });
            });
        })
        .on('error', (e) => {
            console.error(e);
        });
});

module.exports = router;