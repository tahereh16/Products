const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const http = require("http");

const app = express();

//API for interacting
const api = require("./back/routes/api");

//Parsers
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

//DIST output folder
app.use(express.static(path.join(__dirname, "front")));

//API Location
app.use("/api", api);

//Send all other requests to index.html
app.get("", (req, res) => {
    res.sendFile(path.join(__dirname, "front/views/index.html"));
});

//Set app port
const port = process.env.PORT || "3335";
app.set("port", port);

const server = http.createServer(app);
server.listen(port, () => console.log(`Server started on port ${port}`));